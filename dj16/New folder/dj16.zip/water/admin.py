from django.contrib import admin

# Register your models here.
from water.models import Register

admin.site.register(Register)
