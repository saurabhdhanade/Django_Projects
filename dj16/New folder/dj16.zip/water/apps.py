from django.apps import AppConfig


class WaterConfig(AppConfig):
    name = 'water'
